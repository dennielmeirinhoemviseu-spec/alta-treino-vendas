# Backend seguro do ALTA

O app envia a resposta real para `POST /api/sales/coach` quando `window.ALTA_COACH_URL` está configurado. A chave da IA fica somente no servidor, em `AI_MODEL_API_KEY`; nunca é incluída no HTML ou APK.

Sem `AI_MODEL_URL` e `AI_MODEL_API_KEY`, o endpoint funciona em modo offline explícito. Para avaliação sem heurística, configure um endpoint compatível com Chat Completions:

```bash
AI_MODEL_URL=https://seu-provedor/v1/chat/completions AI_MODEL_API_KEY=segredo AI_MODEL_NAME=seu-modelo node server.js
```

O APK local continua funcional sem backend, mas a avaliação de IA real exige publicar esse backend e apontar `window.ALTA_COACH_URL` para ele.
