# ALTA — Treino de Vendas (Android)

Projeto Android configurado para empacotar o Web App ALTA em um APK.

Abra a pasta no Android Studio e use: Build > Build Bundle(s) / APK(s) > Build APK(s).

O app usa os arquivos locais em `app/src/main/assets/`, portanto não depende de servidor para o conteúdo principal.
