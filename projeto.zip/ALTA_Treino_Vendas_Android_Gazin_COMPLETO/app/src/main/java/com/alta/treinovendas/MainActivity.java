package com.alta.treinovendas;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.Window;
import android.graphics.Color;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window w=getWindow(); w.setStatusBarColor(Color.rgb(7,17,31)); w.setNavigationBarColor(Color.rgb(7,17,31));
        WebView web=new WebView(this);
        web.setBackgroundColor(Color.rgb(7,17,31));
        WebSettings s=web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setDatabaseEnabled(true); s.setAllowFileAccess(true); s.setAllowContentAccess(true); s.setBuiltInZoomControls(false); s.setDisplayZoomControls(false);
        web.setWebViewClient(new WebViewClient()); web.setWebChromeClient(new WebChromeClient());
        web.loadUrl("file:///android_asset/index.html"); setContentView(web);
    }
    @Override public void onBackPressed(){ WebView v=(WebView)findViewById(android.R.id.content); super.onBackPressed(); }
}
