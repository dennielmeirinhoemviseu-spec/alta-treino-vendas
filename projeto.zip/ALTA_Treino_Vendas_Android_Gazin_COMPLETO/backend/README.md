# Backend seguro do ALTA

Endpoint local de fallback em `/api/sales/coach`. Em produção, conecte o provedor de IA usando variáveis de ambiente no servidor; nunca inclua chaves no JavaScript ou APK.
